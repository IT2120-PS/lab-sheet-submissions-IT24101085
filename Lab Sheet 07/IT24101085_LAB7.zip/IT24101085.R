# 1
punif(10,min=0,max=30,lower.tail = TRUE)


punif(20,min=0,max=30,lower.tail = FALSE)
1-punif(20,min=0,max=30,lower.tail = TRUE)

#2

pexp(3,rate = 0.5,lower.tail = TRUE)

pexp(4,rate = 0.5,lower.tail = FALSE)
1-pexp(4,rate = 0.5,lower.tail = TRUE)

#p(x<=4)-p(x<=2)
pexp(4,rate = 0.5,lower.tail = TRUE)-pexp(2,rate = 0.5,lower.tail = TRUE)


#3
1-pnorm(37.9,mean = 36.8)

qnorm(0.01,mean=36.8,sd=0.4,lower.tail = FALSE)














getwd()

#1
punif(25,min=0,max=40,lower.tail=TRUE)-punif(10,min=0,max=40,lower.tail=TRUE)

#2
pexp(2,rate=1/3,lower.tail=TRUE)

#3
pnorm(130,mean=100,sd=15,lower.tail = FALSE)     
qnorm(0.95,mean = 100,sd=15,lower.tail = TRUE)
