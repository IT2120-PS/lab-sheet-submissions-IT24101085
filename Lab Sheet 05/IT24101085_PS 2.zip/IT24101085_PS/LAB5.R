getwd()
setwd("/Users/binithijayaweera/Desktop/IT24101085_PS")
getwd()

#Q1
filePAth<-file.choose()
Delivery_Times<-read.table(filePAth,header = TRUE,sep =" ")

#since i need to download the libary n restart the mac i used print keyword to check
fix(Delivery_Times)
print(Delivery_Times)

attach(Delivery_Times)

hist<-hist(Delivery_Time_.minutes.,main = "Deliver Time",breaks = seq(20,70,length=10),right=FALSE)


#Q3
#Symmetrical distibution

#Q4
#frequency
freq<-hist$counts
freq
#mid values
mid<-hist$mids
mid
#Cumulative freq
cumulative_frequency<-cumsum(freq)
cumulative_frequency

plot(mid, cumulative_frequency,type = "o",main = "Cumulative Frequency Polygon of Delivery Times",xlab = "Delivery Time (minutes)",ylab = "Cumulative Frequency")
